<!-- JUMBOTRON -->
<div class="jumbotron jumbotron-fluid">
	<div class="container" align="center">
		<h1 class="display-4">MULAI WEBSITE <br>DARI SINI</h1>
		   <h2>PEMBUATAN WEBSITE & HOSTING</h2>
		  <a href="" class="btn btn-primary tombol2">Pesan</a>
	</div>
</div>
<!-- END JUMBOTRON -->

<div class="content-armadany">
	<div class="container">
		<div class="row justify-content-center row-armadany">
			<div class="col-lg-10 info-panel">
				<h3 class="text-center mb-3 mt-3">Alasan Harus Memilih Kami</h3>
				<div class="row justify-content-center align-items-center">
					<div class="col-lg-12">
						<img src="<?php echo base_url('assets/images/rp-logo.png') ?>" alt="website harga murah" class="float-left">
						<h4>Harga Murah</h4>
						<p>Kami sangat memahami anda yang ingin memiliki website sendiri untuk bisnis atau pribadi, dan kami hadir untuk membantu kalian semua, untuk dapat memiliki website bisnis atau pribadi dengan harga murah, dan terjangkau.</p>
					</div>
					<div class="col-lg-12">
						<img src="<?php echo base_url('assets/images/24-logo.png') ?>" alt="website harga murah" class="float-left">
						<h4>Pelayanan</h4>
						<p>Kami selalu siap melayani anda setiap harinya selama 24 jam, kami bisa memenuhi keinginan anda dengan pelayanan kami yang sangat profesional dan berpengalaman.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>