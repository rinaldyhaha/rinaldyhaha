<?php $this->load->view('templates/open'); ?>
	<div class="home-armadany">
		<main>
			<?php $this->load->view('templates/header'); ?>

			<?php $this->load->view($kontenDinamis); ?>

			<?php $this->load->view('templates/footer'); ?>
		</main>
	</div> <!-- end home-armadany -->
<?php $this->load->view('templates/close') ?>