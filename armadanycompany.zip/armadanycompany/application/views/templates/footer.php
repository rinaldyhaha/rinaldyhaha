	
	<footer class="navbar bg-light navbar-dark footer-armadany">
		<span class="ml-auto">@ArmadanyCompany</span class="ml-auto">
	</footer> 