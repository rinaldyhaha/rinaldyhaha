<!-- navbar -->
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
				  <a class="navbar-brand" href="#">Armadany</a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>
				  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
				    <div class="navbar-nav ml-auto">
				      <a class="nav-item nav-link" href="#">Pembuatan Website</a>
				      <a class="nav-item nav-link" href="#">Products</a>
				      <a class="nav-item nav-link" href="#">Kontak Kami</a>
				    </div>
				  </div>
				</div>
			</nav>
<!-- end navbar -->