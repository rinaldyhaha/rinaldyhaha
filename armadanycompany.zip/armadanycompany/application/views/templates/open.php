<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?= $title ?></title>

	<!-- BOOTSTRAP CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap-4.4.1-dist/css/bootstrap.min.css')?>">

	<!-- MY FONT -->
	<link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

	<!-- MY CSS -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/style.css'); ?>">

</head>
<body>
		
	