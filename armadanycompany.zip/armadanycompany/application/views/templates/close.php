	<!-- jQuery -->
	<script type="text/javascript" src="<?= base_url('assets/js/jquery-3.4.1.slim.min.js'); ?>"></script>

	<!-- popper -->
	<script type="text/javascript" src="<?= base_url('assets/js/popper.min.js'); ?>"></script>

	<!-- js -->
	<script type="text/javascript" src="<?php echo base_url('assets/bootstrap-4.4.1-dist/js/bootstrap.min.js'); ?>"></script>
</body>
</html>