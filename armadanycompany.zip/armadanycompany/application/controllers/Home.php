<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	private $template = 'templates/home/templates.php';

	public function __construct()
	{
		parent::__construct();
	}

	public function index($page = 'pages/home')
	{
		$data['title'] = 'Armadany Company';
		$data['kontenDinamis'] = $page;

		$this->load->view($this->template, $data);
	}
}
